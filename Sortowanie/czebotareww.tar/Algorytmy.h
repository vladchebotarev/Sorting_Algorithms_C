void insert_sort(int *a, int n);
void select_sort(int *a, int n);
void bubble_sort(int *a, int n);
void quick_sort(int *a, int p, int k);
void Shells_sort(int *a, int n);
void heapSort(int *numbers, int array_size);